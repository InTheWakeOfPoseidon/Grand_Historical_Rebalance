-- AI is incompetent in fighting corruption with default budget set to 0.25 max.
NDefines.NAI.CORRUPTION_BUDGET_FRACTION = 0.5
-- Corruption is deadly in this mod. Prevent AI from debasing!
NDefines.NAI.DEBASE_THRESHOLD = 1
-- Allow AI to build tall to spend their excess mana.
NDefines.NAI.DEVELOPMENT_CAP_BASE = 20
NDefines.NAI.DEVELOPMENT_CAP_MULT = 3
-- Twice costly corruption cost, but slider goes twice as far so the relative price will remain the same.
NDefines.NCountry.CORRUPTION_COST = 0.1
-- Culture conversion is 50% more difficult and more costly
NDefines.NCountry.PS_CHANGE_CULTURE = 15
NDefines.NCountry.MONTHS_TO_CHANGE_CULTURE = 15
